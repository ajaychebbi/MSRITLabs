var express = require('express'), routes = require('./routes'), http = require('http'), path = require('path'), fs = require('fs');

var app = express();

var db;

var cloudant;

var dbCredentials = {
	dbName : 'my_survey_form'
};

var bodyParser = require('body-parser');
//all environment
app.set('port', process.env.PORT || 3000);
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.use('/style', express.static(path.join(__dirname, '/views/style')));

function initDBConnection() {
	
	if(process.env.VCAP_SERVICES) {
		var vcapServices = JSON.parse(process.env.VCAP_SERVICES);
		// Pattern match to find the first instance of a Cloudant service in
		// VCAP_SERVICES. If you know your service key, you can access the
		// service credentials directly by using the vcapServices object.
		for(var vcapService in vcapServices){
			if(vcapService.match(/cloudant/i)){
				dbCredentials.host = vcapServices[vcapService][0].credentials.host;
				dbCredentials.port = vcapServices[vcapService][0].credentials.port;
				dbCredentials.user = vcapServices[vcapService][0].credentials.username;
				dbCredentials.password = vcapServices[vcapService][0].credentials.password;
				dbCredentials.url = vcapServices[vcapService][0].credentials.url;
				
				cloudant = require('cloudant')(dbCredentials.url);
				
				// check if DB exists if not create
				cloudant.db.create(dbCredentials.dbName, function (err, res) {
					if (err) { console.log('could not create db ', err); }
				});
				
				db = cloudant.use(dbCredentials.dbName);
				break;
			}
		}
		if(db==null){
			console.warn('Could not find Cloudant credentials in VCAP_SERVICES environment variable - data will be unavailable to the UI');
		}
	} else{
		console.warn('VCAP_SERVICES environment variable not set - data will be unavailable to the UI');
		// For running this app locally you can get your Cloudant credentials 
		// from Bluemix (VCAP_SERVICES in "cf env" output or the Environment 
		// Variables section for an app in the Bluemix console dashboard).
		// Alternately you could point to a local database here instead of a 
		// Bluemix service.
		//dbCredentials.host = "cf003b3b-06b0-495b-9dc7-d74a81884805-bluemix.cloudant.com";
		//dbCredentials.port = 443;
		//dbCredentials.user = "cf003b3b-06b0-495b-9dc7-d74a81884805-bluemix";
		//dbCredentials.password = "a27ab71b3ddcd68deb0d270e43d00f96cfd0036b309bf58b7817d381f3af5b10";
		//dbCredentials.url = "https://cf003b3b-06b0-495b-9dc7-d74a81884805-bluemix:a27ab71b3ddcd68deb0d270e43d00f96cfd0036b309bf58b7817d381f3af5b10@cf003b3b-06b0-495b-9dc7-d74a81884805-bluemix.cloudant.com";

       /* cloudant = require('cloudant')(dbCredentials.url);
				
		// check if DB exists if not create
		cloudant.db.create(dbCredentials.dbName, function (err, res) {
			if (err) { console.log('could not create db ', err); }
		});
		
		db = cloudant.use(dbCredentials.dbName);*/
	}
}

initDBConnection();
app.get('/', routes.index);

app.get('/surveyForm', function(request, response) {

    db.find(
    {
        "selector": {
            "_id": {"$gt":null}
        }
    }
    , function (error, data) {
        if (error) {
            console.log("Data could not retrieved. " + JSON.stringify(error));
            response.status(500).json({ message : "Error while retrieving the survey questions"});
        } else {
            var responseBody = { questions : [] };
            if(data && data.docs) {
                for (var d in data.docs) {    
                    var doc = data.docs[d];
                    var docCopy = JSON.parse(JSON.stringify(doc));
                    responseBody.questions.push(docCopy.question);                  
                }
            }
            response.status(200).json(responseBody);
        }
    });
});

app.post('/surveyQuestion', function(request, response) {
    var question = request.body.question;

    if(question == null) {
        response.status(400).json({ message : "No data specified"});
        return;
    }
    var body = {
        "question" : question,
        "createdTime" : new Date()
    }    
    db.insert(body, function(error, body, header) {
        if(error) {
            console.log("Data not inserted. " + JSON.stringify(error));
            response.status(500).json({ message : "Failed to add question to the database"});
        } else {
            response.status(200).json({ message : "Question added successfully"});
        }
    });
});

http.createServer(app).listen(app.get('port'), '0.0.0.0', function() {
	console.log('Express server listening on port ' + app.get('port'));
});