

function addItem() {
	stopLoadingMessage();
    show(document.getElementById('questionAddDiv'));
    hide(document.getElementById('questionsShowDiv'))
}

function showItem() {

    hide(document.getElementById('questionAddDiv'));
	hide(document.getElementById('questionsShowDiv'))
	showLoadingMessage();
	xhrGet('surveyForm', function(data) {
		console.log(JSON.stringify(data));
		var questions = data.questions;
		if(questions.length == 0) {
			document.getElementById('questionsShowDiv').innerHTML = "No Data Available";
		}
		else {
			var data = "<table class=\"table\">";
			for(i=0; i<questions.length; i++) {
				data += "<tr><td>"+(i+1)+"</td><td>" + questions[i] + "</td></tr>";
				console.log(questions[i]);
			}
			data += "</table>";
			document.getElementById('questionsShowDiv').innerHTML = data;
		}		
		stopLoadingMessage();
		show(document.getElementById('questionsShowDiv'));
	}, function (err) {
		alert("Error in inserting data");
		stopLoadingMessage();
	});
}

function show (elements, specifiedDisplay) {
  elements = elements.length ? elements : [elements];
  for (var index = 0; index < elements.length; index++) {
    elements[index].style.display = specifiedDisplay || 'block';
  }
}

function hide (elements, specifiedDisplay) {
  elements = elements.length ? elements : [elements];
  for (var index = 0; index < elements.length; index++) {
    elements[index].style.display = specifiedDisplay || 'none';
  }
}

function addQuestion() {
    var text = document.getElementById('questionText').value;
    console.log(text);
    if(text == null) {
        alert("Enter the question ");
    }
    else {
        var data = {
            question: text
        }
        xhrPost('surveyQuestion', data, function(item) {
            console.log("Question added");
            document.getElementById('questionText').value= '';
        }, function (err) {
            alert("Error in inserting data");
        });
    }

}


function createXHR(){
	if(typeof XMLHttpRequest != 'undefined'){
		return new XMLHttpRequest();
	}else{
		try{
			return new ActiveXObject('Msxml2.XMLHTTP');
		}catch(e){
			try{
				return new ActiveXObject('Microsoft.XMLHTTP');
			}catch(e){}
		}
	}
	return null;
}

function xhrGet(url, callback, errback){
	var xhr = new createXHR();
	xhr.open("GET", url, true);
	xhr.onreadystatechange = function(){
		if(xhr.readyState == 4){
			if(xhr.status == 200){
				callback(parseJson(xhr.responseText));
			}else{
				errback('service not available');
			}
		}
	};
	
	xhr.timeout = 100000;
	xhr.ontimeout = errback;
	xhr.send();
}

function xhrPost(url, data, callback, errback){
	var xhr = new createXHR();
	xhr.open("POST", url, true);
	//xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("Content-type", "application/json");
	xhr.onreadystatechange = function(){
		if(xhr.readyState == 4){
			if(xhr.status == 200){
				callback(parseJson(xhr.responseText));
			}else{
				errback('service not available');
			}
		}
	};
	xhr.timeout = 100000;
	xhr.ontimeout = errback;
	xhr.send(JSON.stringify(data));
}

function objectToQuery(map){
	var enc = encodeURIComponent, pairs = [];
	for(var name in map){
		var value = map[name];
		var assign = enc(name) + "=";
		if(value && (value instanceof Array || typeof value == 'array')){
			for(var i = 0, len = value.length; i < len; ++i){
				pairs.push(assign + enc(value[i]));
			}
		}else{
			pairs.push(assign + enc(value));
		}
	}
	return pairs.join("&");
}

function parseJson(str){
	return window.JSON ? JSON.parse(str) : eval('(' + str + ')');
}

function showLoadingMessage()
{
	document.getElementById('loadingImage').innerHTML = "Loading data <br>"+"<img height=\"100\" width=\"100\" src=\"images/loading.gif\"></img>";
}
function stopLoadingMessage()
{
	document.getElementById('loadingImage').innerHTML = "";
}
